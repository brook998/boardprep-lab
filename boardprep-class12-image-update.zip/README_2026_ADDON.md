# CBSE Class 12 Physics 2026 add-on

This add-on contains 158 high-confidence deduplicated Section A MCQs and 15 selected single-answer numerical questions from the 15 regular English-medium CBSE 2026 Physics paper sets. It contains 173 original question images. The special visually impaired 55(B) paper is excluded.

## Scope
This is a quality-controlled first batch, not a complete extraction of every question from all 15 papers. It includes Section A MCQs and selected single-value numericals from Sections B/C. Multipart calculations, expression/function answers, long-form responses and teacher-checked questions are not included. Two MCQs for which the official marking scheme gives no valid option/full credit for attempt are withheld from auto-grading.

## Source and answer checking
Question text/images come from the English pages of the supplied CBSE 2026 papers. MCQ answer letters and numerical target values were checked against the matching paper-code official CBSE marking schemes. Assertion/Reason questions include their answer-code instruction in the original image. The prism item in 55/2/2 is √2, as shown in the rendered source paper and marking scheme (the text extraction omits the radical).

## Installation
The included installer adds a clearly marked 2026 block to the existing `class12-image-bank.js`. It does not remove or replace any 2023–2025 CBSE or ISC entries. Images are added under `assets/pyq/class12/CBSE/Physics/2026/`. The existing site already loads `class12-image-bank.js`, so no HTML or service-worker edits are needed. The installer is idempotent: re-running it replaces the marked 2026 block instead of duplicating it.
