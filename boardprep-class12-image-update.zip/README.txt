{
  "title": "Vidhyashram BoardPrep Lab – CBSE Class 12 Physics chapter repair",
  "changes": 259,
  "unassigned_questions_mapped": 254,
  "legacy_chapter_labels_normalized": 5,
  "year_order": [
    2023,
    2024,
    2025,
    2026
  ],
  "2026_note": "2026 records already had catalogue chapter labels; audited and retained unchanged.",
  "mapped_question_counts_by_year": {
    "2023": 100,
    "2024": 74,
    "2025": 80
  },
  "chapter_counts_for_254_mapped_questions": {
    "Semiconductor Electronics": 22,
    "Current Electricity": 23,
    "Atoms": 11,
    "Electromagnetic Induction": 23,
    "Dual Nature of Radiation and Matter": 35,
    "Nuclei": 15,
    "Electric Charges and Fields": 14,
    "Magnetism and Matter": 11,
    "Ray Optics and Optical Instruments": 4,
    "Moving Charges and Magnetism": 31,
    "Alternating Current": 24,
    "Electromagnetic Waves": 21,
    "Wave Optics": 13,
    "Electrostatic Potential and Capacitance": 7
  },
  "safety": "Only the chapter field is changed. Question text, image paths, answer keys, explanations, grading status, and all other records are preserved."
}