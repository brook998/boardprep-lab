# Vidhyashram BoardPrep Lab — Class 12 image-first update

This is an **overlay update**, not a replacement website. It preserves the existing Class 10 bank, Class 12 non-Physics content, practice questions, mock papers, test engine, and PWA files.

## Install with the GitHub Actions automation

1. Add the workflow file at `.github/workflows/install-class12-image-update.yml`.
2. Upload this ZIP to the repository root with the exact filename `boardprep-class12-image-update.zip`.
3. GitHub Actions validates the package, extracts the assets, connects the scripts in both `index.html` and `exam.html`, updates the service-worker cache, removes the uploaded ZIP, and commits the update.
4. Check the **Actions** tab. Wait for a green check before treating the website update as complete.

Do not upload the Android installer ZIP to the repository. Do not extract this integration ZIP manually.

## Included

- `class12-image-bank.js`: 457 student-facing image-first questions (376 CBSE + 81 ISC).
- `image-first-ui.js` and `image-first-ui.css`: show the original question images while retaining the existing answer controls and test engine.
- `assets/pyq/class12/CBSE/Physics/`: CBSE crops, 2023–2025.
- `assets/pyq/class12/ISC/Physics/`: ISC crops, 2023–2026.
- `install_class12_image_update.py`: validator and installer used by the workflow; it is not copied into the live site.

## Safeguards

- Replaces only Class 12 CBSE/ISC Physics records in memory; it does not overwrite `questions.js`, `source-questions.js`, `app.js`, or the other question banks.
- Updates both website entry pages and the service-worker cache while retaining the existing shell entries.
- The previously missing crop for the existing CBSE 2025 paper 55/6/3 Q18(b) numerical record is restored at `assets/pyq/class12/CBSE/Physics/2025/CBSE12-2025-55-6-3-Q18b.png`. The existing record is preserved; no new question was added.
- Ten additional image-only/withheld assets remain files only; they do not create extra question records.
- No teacher answer-key archives are included.
- This static client-side site is not a secure high-stakes examination platform.

## Package QA

- 457 unique active `sourceImage` references checked; all 457 files exist in the ZIP.
- 467 image assets present (385 PNG and 82 JPEG); all decoded successfully.
- 457 student records: 376 CBSE + 81 ISC.
- No missing active image references.
- Browser/mobile end-to-end testing has not yet been performed.
