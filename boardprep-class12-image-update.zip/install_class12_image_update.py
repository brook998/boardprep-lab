#!/usr/bin/env python3
"""Install the append-only CBSE Class 12 Physics 2026 add-on."""
from pathlib import Path
import json, sys, zipfile
archive=Path(sys.argv[1] if len(sys.argv)>1 else 'boardprep-class12-image-update.zip')
if not archive.is_file(): raise SystemExit(f'Missing update archive: {archive}')
start='/* BEGIN VIDHYASHRAM CBSE12 PHYSICS 2026 ADD-ON */'
end='/* END VIDHYASHRAM CBSE12 PHYSICS 2026 ADD-ON */'
with zipfile.ZipFile(archive) as z:
    bad=z.testzip()
    if bad: raise SystemExit(f'ZIP integrity failure: {bad}')
    names=set(z.namelist())
    required={'class12-cbse-2026-bank.js','manifest.json','install_class12_image_update.py'}
    if required-names: raise SystemExit(f'Missing ZIP files: {sorted(required-names)}')
    manifest=json.loads(z.read('manifest.json').decode())
    if manifest.get('recordCount')!=173 or manifest.get('imageCount')!=173: raise SystemExit('Unexpected manifest counts.')
    js=z.read('class12-cbse-2026-bank.js').decode()
    records=json.loads(js.split('window.QUESTION_BANK.push(...',1)[1].rsplit(');',1)[0])
    if len(records)!=173: raise SystemExit(f'Expected 173 records; got {len(records)}')
    ids=[r['id'] for r in records]
    if len(ids)!=len(set(ids)): raise SystemExit('Duplicate question IDs in update.')
    image_refs=[]
    for q in records:
        if (q.get('class'),q.get('board'),q.get('subject'),q.get('year'))!=('12','CBSE','Physics',2026): raise SystemExit(f'Out-of-scope record {q.get("id")}')
        p=q.get('sourceImage','')
        if not p.startswith('assets/pyq/class12/CBSE/Physics/2026/') or p not in names: raise SystemExit(f'Missing image {p}')
        image_refs.append(p)
        if q.get('type')=='source-mcq' and (q.get('answerKeyLetter') not in 'ABCD' or q.get('gradingStatus')!='verified'): raise SystemExit(f'Invalid MCQ key {q.get("id")}')
        if q.get('type')=='numeric' and (not isinstance(q.get('answer'),(int,float)) or not isinstance(q.get('tolerance'),(int,float))): raise SystemExit(f'Invalid numeric {q.get("id")}')
        if q.get('type') not in ('source-mcq','numeric'): raise SystemExit(f'Unsupported type {q.get("type")}')
    if len(set(image_refs))!=173: raise SystemExit('Expected 173 distinct images.')
    for p in image_refs:
        b=z.read(p)
        if len(b)<1000 or not b.startswith(b'\xff\xd8'): raise SystemExit(f'Invalid JPEG {p}')
    for p in image_refs:
        dst=Path(p);dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(z.read(p))
bank=Path('class12-image-bank.js')
if not bank.is_file(): raise SystemExit('class12-image-bank.js not found.')
old=bank.read_text(encoding='utf-8')
block=f'{start}\n{js.rstrip()}\n{end}'
if start in old:
    a=old.index(start)
    if end not in old[a:]: raise SystemExit('Existing add-on marker is incomplete; refusing to alter bank.')
    b=old.index(end,a)+len(end)
    new=old[:a]+block+old[b:]
else:
    collision=[qid for qid in ids if qid in old]
    if collision: raise SystemExit(f'Question IDs already exist: {collision[:5]}')
    new=old.rstrip()+'\n\n'+block+'\n'
bank.write_text(new,encoding='utf-8')
print(f'Installed {len(records)} 2026 CBSE Physics questions and {len(set(image_refs))} images.')
print('Existing CBSE 2023–2025 and ISC records preserved.')
