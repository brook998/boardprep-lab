#!/usr/bin/env python3
"""Validate and install the Vidhyashram Class 12 image-first overlay."""
from pathlib import Path, PurePosixPath
import json, re, sys, zipfile

archive = Path(sys.argv[1] if len(sys.argv) > 1 else "boardprep-class12-image-update.zip")
root = Path.cwd()
if not archive.is_file():
    raise SystemExit(f"Update ZIP not found: {archive}")

with zipfile.ZipFile(archive) as z:
    bad = z.testzip()
    if bad:
        raise SystemExit(f"ZIP CRC check failed for {bad}")
    infos = [i for i in z.infolist() if not i.is_dir()]
    if len(infos) > 1100 or sum(i.file_size for i in infos) > 110 * 1024 * 1024:
        raise SystemExit("The update ZIP exceeds the safety limits.")

    parts_list = [PurePosixPath(i.filename).parts for i in infos]
    wrapper = None
    if parts_list and all(len(p) > 1 and p[0].endswith("_Update") for p in parts_list):
        roots = {p[0] for p in parts_list}
        if len(roots) == 1:
            wrapper = next(iter(roots))

    payload = {}
    for info, parts in zip(infos, parts_list):
        p = PurePosixPath(info.filename)
        if p.is_absolute() or ".." in p.parts or "\\" in info.filename:
            raise SystemExit(f"Unsafe ZIP path rejected: {info.filename}")
        if wrapper:
            parts = parts[1:]
        rel = "/".join(parts)
        if not rel:
            continue
        allowed_file = rel in {
            "class12-image-bank.js", "image-first-ui.js", "image-first-ui.css",
            "README_INSTALL.md", "INDEX_HTML_INSERTIONS.txt", "UPDATE_MANIFEST.json",
            "IMAGE_FILE_INVENTORY.json", "FINAL_QA_REPORT.txt", "install_class12_image_update.py",
        }
        allowed_image = rel.startswith("assets/pyq/class12/") and rel.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))
        if not (allowed_file or allowed_image):
            raise SystemExit(f"Unexpected file in update ZIP: {rel}")
        payload[rel] = z.read(info)

required = ("class12-image-bank.js", "image-first-ui.js", "image-first-ui.css", "UPDATE_MANIFEST.json")
missing_required = [p for p in required if p not in payload]
if missing_required:
    raise SystemExit("ZIP is missing: " + ", ".join(missing_required))
manifest = json.loads(payload["UPDATE_MANIFEST.json"])
if manifest.get("record_count") != 457 or manifest.get("image_count") != 467 or manifest.get("missing_images") != 0:
    raise SystemExit("Manifest does not match expected 457-question / 467-image release.")

bank = payload["class12-image-bank.js"].decode("utf-8")
records = len(re.findall(r'"id"\s*:', bank))
refs = re.findall(r'"sourceImage"\s*:\s*"([^"]+)"', bank)
if records != 457 or len(refs) != 457 or len(set(refs)) != 457:
    raise SystemExit("Question count or unique image-reference check failed.")
image_paths = {p for p in payload if p.startswith("assets/pyq/class12/")}
if len(image_paths) != 467:
    raise SystemExit(f"Expected 467 image files; found {len(image_paths)}.")
missing_refs = sorted(set(refs) - image_paths)
if missing_refs:
    raise SystemExit("Missing referenced images: " + ", ".join(missing_refs[:20]))

# Copy only deployable files; docs and this installer remain out of the site.
for rel, data in payload.items():
    if rel in ("class12-image-bank.js", "image-first-ui.js", "image-first-ui.css") or rel.startswith("assets/pyq/class12/"):
        target = root / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

# Add the image-first stylesheet and scripts to both pages, idempotently.
for filename in ("index.html", "exam.html"):
    path = root / filename
    if not path.is_file():
        raise SystemExit(f"Required page missing: {filename}")
    text = path.read_text(encoding="utf-8")
    css = '<link rel="stylesheet" href="image-first-ui.css">'
    if css not in text:
        anchor = '<link rel="stylesheet" href="styles.css">'
        if anchor not in text:
            raise SystemExit(f"Could not find styles.css in {filename}")
        text = text.replace(anchor, anchor + "\n  " + css, 1)
    bank_tag = '<script src="class12-image-bank.js"></script>'
    if bank_tag not in text:
        anchor = '<script src="practice-expansion.js"></script>'
        if anchor not in text:
            raise SystemExit(f"Could not find practice-expansion.js in {filename}")
        text = text.replace(anchor, anchor + "\n  " + bank_tag, 1)
    ui_tag = '<script src="image-first-ui.js"></script>'
    if ui_tag not in text:
        anchor = '<script src="app.js"></script>'
        if anchor not in text:
            raise SystemExit(f"Could not find app.js in {filename}")
        text = text.replace(anchor, anchor + "\n  " + ui_tag, 1)
    if not (text.index(bank_tag) < text.index('<script src="app.js"></script>') < text.index(ui_tag)):
        raise SystemExit(f"Script order validation failed in {filename}")
    path.write_text(text, encoding="utf-8")

# Bump the cache version, preserve current entries, and add the new files.
sw_path = root / "sw.js"
if not sw_path.is_file():
    raise SystemExit("sw.js is missing")
sw = sw_path.read_text(encoding="utf-8")
if "vidhyashram-boardprep-shell-v6" in sw:
    sw = sw.replace("vidhyashram-boardprep-shell-v6", "vidhyashram-boardprep-shell-v7")
elif "vidhyashram-boardprep-shell-v7" not in sw:
    raise SystemExit("Unrecognised service-worker cache version; no change made")
match = re.search(r"(const\s+SHELL\s*=\s*\[)(.*?)(\];)", sw, re.S)
if not match:
    raise SystemExit("Could not safely locate the SHELL cache array")
body = match.group(2).rstrip()
additions = ["'./class12-image-bank.js'", "'./image-first-ui.js'", "'./image-first-ui.css'"]
missing = [item for item in additions if item not in body]
if missing:
    body = body.rstrip().rstrip(",")
    if body:
        body += ","
    for i, item in enumerate(missing):
        body += "\n  " + item + ("," if i < len(missing) - 1 else "")
    body += "\n"
sw = sw[:match.start()] + match.group(1) + body + match.group(3) + sw[match.end():]
sw_path.write_text(sw, encoding="utf-8")

print(f"INSTALLER PASS: {records} Class 12 records, {len(set(refs))} referenced images, {len(image_paths)} bundled images.")
