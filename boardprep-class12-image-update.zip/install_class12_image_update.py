#!/usr/bin/env python3
"""Safely install the BoardPrep Lab image-first UI hotfix from the uploaded ZIP."""
from pathlib import Path
import sys
import zipfile

archive = Path(sys.argv[1] if len(sys.argv) > 1 else "boardprep-class12-image-update.zip")
target = Path("image-first-ui.js")

if not archive.is_file():
    raise SystemExit(f"Update archive not found: {archive}")

with zipfile.ZipFile(archive) as zf:
    bad = zf.testzip()
    if bad:
        raise SystemExit(f"ZIP integrity check failed at: {bad}")
    matches = [name for name in zf.namelist() if name == "image-first-ui.js"]
    if len(matches) != 1:
        raise SystemExit(
            "Expected exactly one root-level image-first-ui.js in the ZIP. "
            f"Found: {matches!r}; archive entries: {zf.namelist()!r}"
        )
    content = zf.read(matches[0])

if len(content) < 1000:
    raise SystemExit("The image-first-ui.js file is unexpectedly small; refusing to install.")

# Keep the update confined to this one known application file.
target.write_bytes(content)
print(f"Installed {target} ({len(content)} bytes).")
