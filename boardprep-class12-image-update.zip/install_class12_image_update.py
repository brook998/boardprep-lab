#!/usr/bin/env python3
"""Safely apply chapter-only corrections to BoardPrep Lab's Class 12 image bank."""
import json, re, sys, zipfile
from pathlib import Path

BANK = Path("class12-image-bank.js")
ALLOWED = {
    "Electric Charges and Fields", "Electrostatic Potential and Capacitance",
    "Current Electricity", "Moving Charges and Magnetism", "Magnetism and Matter",
    "Electromagnetic Induction", "Alternating Current", "Electromagnetic Waves",
    "Ray Optics and Optical Instruments", "Wave Optics",
    "Dual Nature of Radiation and Matter", "Atoms", "Nuclei",
    "Semiconductor Electronics",
}

def object_spans(source):
    depth_brace = depth_bracket = 0
    in_string = escaped = False
    start = None
    for i, ch in enumerate(source):
        if in_string:
            if escaped:
                escaped = False
            elif ch == "\\":
                escaped = True
            elif ch == '"':
                in_string = False
            continue
        if ch == '"':
            in_string = True
        elif ch == '[':
            depth_bracket += 1
        elif ch == ']':
            depth_bracket -= 1
        elif ch == '{':
            if depth_brace == 0 and depth_bracket >= 1:
                start = i
            depth_brace += 1
        elif ch == '}':
            depth_brace -= 1
            if depth_brace == 0 and start is not None:
                yield start, i + 1
                start = None

def main():
    if not BANK.exists():
        raise SystemExit("class12-image-bank.js is missing; no changes made.")
    if len(sys.argv) < 2:
        raise SystemExit("Installer requires the uploaded ZIP path; no changes made.")
    with zipfile.ZipFile(sys.argv[1], "r") as package:
        updates = json.loads(package.read("chapter_updates.json").decode("utf-8"))
    if len(updates) != 259 or set(updates.values()) - ALLOWED:
        raise SystemExit("Chapter update data failed validation; no changes made.")
    original = BANK.read_text(encoding="utf-8")
    source = original
    found = {}
    replacements = []
    for start, end in object_spans(source):
        block = source[start:end]
        mid = re.search(r'"id"\s*:\s*"([^"]+)"', block)
        if not mid:
            continue
        qid = mid.group(1)
        if qid not in updates:
            continue
        cm = re.search(r'("chapter"\s*:\s*)(null|"[^"]*")', block)
        if not cm:
            raise SystemExit(f"Chapter field missing for {qid}; no changes made.")
        changed = block[:cm.start(2)] + json.dumps(updates[qid], ensure_ascii=False) + block[cm.end(2):]
        replacements.append((start, end, changed))
        found[qid] = found.get(qid, 0) + 1

    missing = sorted(set(updates) - set(found))
    duplicates = sorted(q for q, n in found.items() if n != 1)
    if missing or duplicates:
        raise SystemExit(f"ID validation failed; missing={missing[:5]}, duplicates={duplicates[:5]}; no changes made.")

    for start, end, changed in reversed(replacements):
        source = source[:start] + changed + source[end:]

    # Validate every updated record by reading its complete object span.
    validated = set()
    for start, end in object_spans(source):
        block = source[start:end]
        mid = re.search(r'"id"\s*:\s*"([^"]+)"', block)
        cm = re.search(r'"chapter"\s*:\s*(null|"[^"]*")', block)
        if mid and mid.group(1) in updates and cm:
            if json.loads(cm.group(1)) != updates[mid.group(1)]:
                raise SystemExit(f"Post-edit validation failed for {mid.group(1)}; no changes written.")
            validated.add(mid.group(1))
    if validated != set(updates):
        raise SystemExit("Post-edit completeness check failed; no changes written.")

    backup = BANK.with_suffix(".js.chapter-repair-backup")
    if not backup.exists():
        backup.write_text(original, encoding="utf-8")
    BANK.write_text(source, encoding="utf-8")
    print(f"Applied {len(validated)} chapter-only updates; all other question fields preserved.")

if __name__ == "__main__":
    main()
