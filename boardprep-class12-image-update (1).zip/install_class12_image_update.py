#!/usr/bin/env python3
"""Install only the BoardPrep image-first UI hotfix from this archive."""
from pathlib import Path
import sys
import zipfile

archive = Path(sys.argv[1] if len(sys.argv) > 1 else "boardprep-class12-image-update.zip")
with zipfile.ZipFile(archive) as z:
    names = set(z.namelist())
    required = {"image-first-ui.js"}
    missing = required - names
    if missing:
        raise SystemExit("Hotfix archive is missing: " + ", ".join(sorted(missing)))
    content = z.read("image-first-ui.js")
    # Refuse unexpected oversized or empty script payloads.
    if not content or len(content) > 100_000:
        raise SystemExit("image-first-ui.js has an unexpected size.")
    Path("image-first-ui.js").write_bytes(content)
print("Installed corrected image-first-ui.js only; question banks and image assets were not changed.")
